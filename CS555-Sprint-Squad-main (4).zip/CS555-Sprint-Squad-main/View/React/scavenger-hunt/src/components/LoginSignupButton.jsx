import "./button.css";
import PropTypes from 'prop-types';

const LoginSignupButton = ({ btnText, clickHandler ,setModalOpen}) => {
  return (
    <>
      <button
        onClick={() => {
          clickHandler((s) => !s);
          // setModalOpen((s)=>!s)
        }}
      >
        {btnText}
      </button>
    </>
  );
};

LoginSignupButton.propTypes = 
{
  btnText: PropTypes.string.isRequired,
  clickHandler: PropTypes.func.isRequired,
  setModalOpen: PropTypes.func.isRequired,
};

export default LoginSignupButton;
