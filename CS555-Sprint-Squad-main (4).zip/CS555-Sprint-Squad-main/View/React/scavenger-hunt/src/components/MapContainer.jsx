import HamburgerMenu from "./HamburgerMenu";
import React from 'react';
import PropTypes from 'prop-types';

function MapContainer(props) {
  return (
    <div className="mapContainer">
      <nav>
        <p>User name</p>
        <p>Current scavenger hunt name</p>
        <HamburgerMenu/>
      </nav>
      {props.children}
    </div>
  );
}

MapContainer.PropTypes = 
{
  children: PropTypes.node.isRequired,
};

export default MapContainer;
