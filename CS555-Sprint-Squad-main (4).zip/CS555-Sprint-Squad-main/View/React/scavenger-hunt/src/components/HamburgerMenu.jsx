function HamburgerMenu(props) {
  return (
    <div>
    <div className="hamburger"></div>
    <div className="hamburger"></div>
    <div className="hamburger"></div>
   
    </div>
    
    
  );
}

export default HamburgerMenu;
