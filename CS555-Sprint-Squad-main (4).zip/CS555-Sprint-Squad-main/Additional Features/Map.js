//window.open("https://www.creativeforce.com/wp-content/uploads/2015/12/hoboken-jersey-city-downtown-map1.jpg");
//open a map of Hoboken (and Jersey City)
//have overlaying icons over notable areas
