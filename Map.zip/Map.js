//window.open("https://www.creativeforce.com/wp-content/uploads/2015/12/hoboken-jersey-city-downtown-map1.jpg");
//open a map of Hoboken (and Jersey City)
//have overlaying icons over notable areas
//upon clicking, pop up image and description of area
//click 'x' button or outside of box to close it